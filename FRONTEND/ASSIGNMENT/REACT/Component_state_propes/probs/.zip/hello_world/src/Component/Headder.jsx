

import React from 'react'

const Headder = () => {
  return (
        <h1>REACT JS</h1>
  )
}

export default Headder