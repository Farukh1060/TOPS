import { useState } from 'react'
import reactLogo from './assets/react.svg'
import Headder from './Component/Headder'
import Hello from './Component/Hello'
import Logo from './Component/logo'


function App() {
  
  return(<center>
  <Headder></Headder>
  <Logo></Logo>
  <Hello></Hello>
  
  </center>)
}

export default App
