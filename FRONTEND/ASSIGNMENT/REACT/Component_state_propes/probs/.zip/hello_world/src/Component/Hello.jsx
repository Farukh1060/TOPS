

import React from 'react'

function Hello() {
  return (
    <h2>Hello world</h2>
  )
}

export default Hello