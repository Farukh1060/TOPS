
import logo from "../assets/react.svg"
import React from 'react'

const Logo = () => {
  return (
    <div><img src={logo} alt="" /></div>
  )
}

export default Logo