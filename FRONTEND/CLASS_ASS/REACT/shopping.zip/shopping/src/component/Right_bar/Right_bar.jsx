import "./Right_bar.css"


const Right_bar =() =>{
    return(<div className="container">
        <div className="row">
            <div className="coll-4">
                <div className="right_bar">
                    <h1>catagory</h1>
                </div>
            </div>
        </div>
    </div>)
}
export default Right_bar