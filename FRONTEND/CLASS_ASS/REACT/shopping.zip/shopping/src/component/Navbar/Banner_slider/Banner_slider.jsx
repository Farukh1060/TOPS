
const Banner_slider =() =>{
    return(
        <div className="container">
            <div className="row">
                <div className="col-12">
                    <div className="img_container">
                        <img src="" alt="" />
                    </div>
                </div>
            </div>
        </div>
        
    )
}

export default Banner_slider