import React from "react"
import "./App.css"
import Navbar from "./component/Navbar/Navbar"
import Right_bar from "./component/Right_bar/Right_bar"
  


const App =()=>{

  const menu = ["shop","men","women","kids"]



  return(
    <>
     <Navbar menu={menu}></Navbar>
    <Right_bar></Right_bar>
    </>
  )
}

export default App  