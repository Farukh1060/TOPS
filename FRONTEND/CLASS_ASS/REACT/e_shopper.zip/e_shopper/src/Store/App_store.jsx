import { createContext, useEffect, useReducer } from "react"



export const Productcontax =  createContext()




const Productcontexprovider = ({childern})=>{


//    const productlistreduser =(currentstate,action)=>{
//     if(action.type=="initpost"){
//         return currentstate = action.paylode
//     }

//    }

//     const [productlist,productdispatch] = useReducer(productlistreduser,[])

//     useEffect(()=>{

//         fetch("https://dummyjson.com/products").then(data=>
//             {
//                 return data.json()
//             }).then(result=>{
//                 result.products
//               const  productlistdata = {
//                 type:"initpost",
//                 paylode:result.products
//               }

//                 productdispatch(productlistdata)
//             })
//     },[]
        
//     )



    console.log(childern)
    return(
       <Productcontax.Provider value={{}}>
        {childern}
       </Productcontax.Provider>
    )

}

export default Productcontexprovider