


function Title(){
    return <>
    <center><h1>TO-DO-LIST</h1></center>
    </>
    
}
export default Title